<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
    
    <head>
        <meta charset="utf-8">
        <title></title>
        <meta name="renderer" content="webkit">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="format-detection" content="telephone=no">
        <link rel="stylesheet" href="/addons/yb_pingche/Public/css/x-admin.css" media="all">
        <script src="/addons/yb_pingche/Public/js/jquery.js"></script>     
    </head>
    
    <body>
        <div class="x-body">
       <div class="x-nav">
            <span class="layui-breadcrumb">
              <a><cite>首页</cite></a>
              <a><cite>基本设置</cite></a>
              <a><cite>拼车参数</cite></a>
            </span>
            <a class="layui-btn layui-btn-small" style="line-height:1.6em;margin-top:3px;float:right"  href="javascript:location.replace(location.href);" title="刷新"><i class="layui-icon" style="line-height:30px">ဂ</i></a>
        </div>       
            <form class="layui-form layui-form-pane" id="form1" name="form1" method="post" action="<?php echo U('Subset/update');?>">
                <div class="layui-form-item" style="margin-top:20px;">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>车主押金</label>
                    <div class="layui-input-inline" style="width:70%;">
                        <input type="text" name="member_deposit"  value="<?php echo ($data['member_deposit']); ?>"  placeholder="" autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-form-mid layui-word-aux">
                    	<span>(单位：元)车主押金必须保持的最小金额</span>
                    </div> 
                </div>
                <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>红包提现最小金额</label>
                    <div class="layui-input-inline" style="width:70%;">
                        <input  type="text" name="member_redpacked"  value="<?php echo ($data['member_redpacked']); ?>" placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>(单位：元)如：1 [注备：最小1元]
					</div>
                </div>
                 <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>会员分享所得金额</label>
                    <div class="layui-input-inline" style="width:70%;">
                        <input type="text" name="member_share"  value="<?php echo ($data['member_share']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>(单位：元)如：20
					</div>                     
                </div>               
                 <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>车主邀请车主分享所得金额</label>
                    <div class="layui-input-inline" style="width:70%;">
                        <input type="text" name="car_owner_share"  value="<?php echo ($data['car_owner_share']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>(单位：元)如：20
					</div>                    
                </div>
                 <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>订单最小金额</label>
                    <div class="layui-input-inline" style="width:70%;">
                        <input type="text" name="member_jine"  value="<?php echo ($data['member_jine']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
	                <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>(单位：元)如：20
					</div>                   
                </div>                 
                 <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>车主每天发布最大任务数目</label>
                    <div class="layui-input-inline" style="width:70%;">
                        <input type="text" name="member_taskcount"  value="<?php echo ($data['member_taskcount']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>如：2
					</div>                    
                </div>                
                 <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>冻结车主订单押金扣除</label>
                    <div class="layui-input-inline" style="width:70%;">
                        <input type="text" name="platform_plat_car_owner1"  value="<?php echo ($data['platform_plat_car_owner1']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>如：0.1
					</div>                    
                </div>
                <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>冻结乘客订单扣除车资</label>
                    <div class="layui-input-inline" style="width:70%;">
                        <input type="text" name="platform_plat_passenger2"  value="<?php echo ($data['platform_plat_passenger2']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>如：0.1
					</div>                   
                </div>
                <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>冻结乘客订单平台获取扣除车资中的服务费</label>
                    <div class="layui-input-inline" style="width:70%;">
                        <input type="text" name="platform_plat_dj_passenger"  value="<?php echo ($data['platform_plat_dj_passenger']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>如：0.1
					</div>                   
                </div>
                 <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>冻结车主订单平台获取扣除押金中的服务费</label>
                    <div class="layui-input-inline" style="width:70%;">
                        <input type="text" name="platform_plat_dj_car_owner"  value="<?php echo ($data['platform_plat_dj_car_owner']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>如：0.1
					</div>                  
                </div>
                 <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>车主任务直接取消任务平台获得押金的值</label>
                    <div class="layui-input-inline" style="width:70%;">
                        <input type="text" name="platform_platform"  value="<?php echo ($data['platform_platform']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>如：0.1
					</div>                   
                </div>                
                <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>车主任务直接取消乘客获得押金的值</label>
                    <div class="layui-input-inline" style="width:70%;">
                        <input type="text" name="platform_car_owner"  value="<?php echo ($data['platform_car_owner']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>如：0.1
					</div>                   
                </div>               
                <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>乘客直接取消任务给车主的值</label>
                    <div class="layui-input-inline" style="width:70%;">
                        <input type="text" name="platform_passenger"  value="<?php echo ($data['platform_passenger']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>如：0.1
					</div>                   
                </div>
                 <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>平台服务费</label>
                    <div class="layui-input-inline" style="width:70%;">
                       <input type="text" name="platform_cover_charge"  value="<?php echo ($data['platform_cover_charge']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>单位：元
					</div>                   
                </div>
                <div class="layui-form-item" style="margin-top:20px;">
                        <label class="layui-form-label" style="width:175px;"><span class="x-red">*</span>是否自动计算价格</label>
                        <div class="layui-input-inline" style="width:70%;">
                            <select lay-verify="required" name="is_autoprice" id="is_autoprice">
                                <option>
                                </option>
                                <optgroup label="请选择">
                                    <option value="1" <?php if($data['is_autoprice'] == 1) echo 'selected=""' ?>>不自动计算价格</option>
                                    <option value="2" <?php if($data['is_autoprice'] == 2) echo 'selected=""' ?>>自动计算价格</option>
                                </optgroup>
                            </select><span id="nstatusa"></span>
                        </div>
                </div>                 
                <div class="layui-form-item" style="margin-top:20px;">
                        <label class="layui-form-label" style="width:175px;"><span class="x-red">*</span>是否限制提前取消时间</label>
                        <div class="layui-input-inline" style="width:70%;">
                             <select lay-verify="required" name="is_ordercanel" id="is_ordercanel">
                                <option>
                                </option>
                                <optgroup label="请选择">
                                    <option value="1" <?php if($data['is_ordercanel'] == 1) echo 'selected=""' ?>>不限制</option>
                                    <option value="2" <?php if($data['is_ordercanel'] == 2) echo 'selected=""' ?>>限制</option>
                                </optgroup>
                            </select><span id="nstatusa"></span>
                        </div>
                </div>                
                  <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>提前取消时间</label>
                    <div class="layui-input-inline" style="width:70%;">
                       <input type="text" name="ordercaneltime"  value="<?php echo ($data['ordercaneltime']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>单位：分钟
					</div>                   
                </div>
                   <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>车主任务终点数量</label>
                    <div class="layui-input-inline" style="width:70%;">
                       <input type="text" name="station_num"  value="<?php echo ($data['station_num']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>例：0表示不限，大于0表示限制个数
					</div>                   
                </div>                                             
                 <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>起步价</label>
                    <div class="layui-input-inline" style="width:70%;">
                       <input type="text" name="start_price"  value="<?php echo ($data['start_price']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>单位：元
					</div>                   
                </div>
                 <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>短程起步里程标准</label>
                    <div class="layui-input-inline" style="width:70%;">
                       <input type="text" name="sstart_mileage"  value="<?php echo ($data['sstart_mileage']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>单位：元
					</div>                   
                </div>                
                  <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>短程每公里单价</label>
                    <div class="layui-input-inline" style="width:70%;">
                       <input type="text" name="skm_price"  value="<?php echo ($data['skm_price']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>单位：元
					</div>                   
                </div>
                   <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>远程每公里单价</label>
                    <div class="layui-input-inline" style="width:70%;">
                       <input type="text" name="bkm_price"  value="<?php echo ($data['bkm_price']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>单位：元
					</div>                   
                </div>               
                   <div class="layui-form-item">
                    <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>远程里程数标准</label>
                    <div class="layui-input-inline" style="width:70%;">
                       <input type="text" name="bstart_mileage"  value="<?php echo ($data['bstart_mileage']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
                    </div>
                    <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>单位：公里
					</div>                   
                </div>                
                <div class="layui-form-item" style="margin-top:20px;">
                        <label class="layui-form-label" style="width:175px;"><span class="x-red">*</span>车主奖励开关</label>
                        <div class="layui-input-inline" style="width:70%;">
                             <select lay-verify="required" name="co_awards_status" id="co_awards_status">
                                <option>
                                </option>
                                <optgroup label="请选择">
                                    <option value="1" <?php if($data['co_awards_status'] == 1) echo 'selected=""' ?>>关闭</option>
                                    <option value="2" <?php if($data['co_awards_status'] == 2) echo 'selected=""' ?>>打开</option>
                                </optgroup>
                            </select><span id="co_awards_statusa"></span>
                        </div>
                </div>
                <div class="layui-form-item" style="margin-top:20px;">
                        <label class="layui-form-label" style="width:175px;"><span class="x-red">*</span>车主奖励方式</label>
                        <div class="layui-input-inline" style="width:70%;">
                             <select lay-verify="required" name="co_awards_type" id="co_awards_type">
                                <option>
                                </option>
                                <optgroup label="请选择">
                                    <option value="1" <?php if($data['co_awards_type'] == 1) echo 'selected=""' ?>>整数</option>
                                    <option value="2" <?php if($data['co_awards_type'] == 2) echo 'selected=""' ?>>百分比</option>
                                </optgroup>
                            </select><span id="co_awards_typea"></span>
                        </div>
                </div>                                
                <div class="layui-form-item">
	                  <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>车主奖励值</label>
	                  <div class="layui-input-inline" style="width:70%;">
	                     <input type="text" name="co_awards_value"  value="<?php echo ($data['co_awards_value']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
	                  </div>
	                  <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>
					  </div>                   
               </div>
                <div class="layui-form-item" style="margin-top:20px;">
                        <label class="layui-form-label" style="width:175px;"><span class="x-red">*</span>乘客奖励开关</label>
                        <div class="layui-input-inline" style="width:70%;">
                             <select lay-verify="required" name="passenger_awards_status" id="passenger_awards_status">
                                <option>
                                </option>
                                <optgroup label="请选择">
                                    <option value="1" <?php if($data['passenger_awards_status'] == 1) echo 'selected=""' ?>>关闭</option>
                                    <option value="2" <?php if($data['passenger_awards_status'] == 2) echo 'selected=""' ?>>打开</option>
                                </optgroup>
                            </select><span id="passenger_awards_statusa"></span>
                        </div>
                </div>
                <div class="layui-form-item" style="margin-top:20px;">
                        <label class="layui-form-label" style="width:175px;"><span class="x-red">*</span>乘客奖励方式</label>
                        <div class="layui-input-inline" style="width:70%;">
                             <select lay-verify="required" name="passenger_awards_type" id="passenger_awards_type">
                                <option>
                                </option>
                                <optgroup label="请选择">
                                    <option value="1" <?php if($data['passenger_awards_type'] == 1) echo 'selected=""' ?>>整数</option>
                                    <option value="2" <?php if($data['passenger_awards_type'] == 2) echo 'selected=""' ?>>百分比</option>
                                </optgroup>
                            </select><span id="passenger_awards_typea"></span>
                        </div>
                </div>                                
                <div class="layui-form-item">
	                  <label for="L_title" class="layui-form-label" style="width:175px;"><span class="x-red">*</span>乘客奖励值</label>
	                  <div class="layui-input-inline" style="width:70%;">
	                     <input type="text" name="passenger_awards_value"  value="<?php echo ($data['passenger_awards_value']); ?>"  placeholder="" autocomplete="off" class="layui-input" >
	                  </div>
	                  <div class="layui-form-mid layui-word-aux">
						<span class="x-red"></span>
					  </div>                   
               </div>
                <div class="layui-form-item" style="margin-top:20px;">
                        <label class="layui-form-label" style="width:175px;"><span class="x-red">*</span>是否显示手机号</label>
                        <div class="layui-input-inline" style="width:70%;">
                             <select lay-verify="required" name="mobileshow_status" id="mobileshow_status">
                                    <option value="1" <?php if($data['mobileshow_status'] == 1) echo 'selected=""' ?>>隐藏</option>
                                    <option value="2" <?php if($data['mobileshow_status'] == 2) echo 'selected=""' ?>>显示</option>
                            </select><span id="mobileshow_statusa"></span>
                        </div>
                </div>			   
                <div class="layui-form-item">
                    <button class="layui-btn" id="nclick">提交信息</button>
                </div>
            </form>
        </div>
		<script src="/addons/yb_pingche/Public/layui/layui.js" charset="utf-8"></script>
		<script src="/addons/yb_pingche/Public/js/x-layui.js" charset="utf-8"></script>
		<script>
		layui.use(['element','layer','layedit','form'], function(){
			  layedit = layui.layedit;  
			  //lement = layui.element();//面包导航
			  layer = layui.layer;//弹出层
			  //form = layui.form();
		});    
		</script>
    </body>
</html>